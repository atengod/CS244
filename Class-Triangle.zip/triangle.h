//Triangle class declaration
//Triangle.h

#include <iostream>
using namespace std;

class Triangle
{
private:
  double base;
  double height;

public:
  Triangle();  //Constructor
  
  //getters
  
  double getHeight() const; 
  double getBase() const;
  double getArea() const;
  
  //setters
  
  void setBase(double);
  void setHeight(double);
};