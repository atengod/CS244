//main.ccpp
#include<iostream>

//#include "triangle.h"

#include "triangle.cc"

using namespace std;

int main()
{

Triangle ob;
double triHeight;
double triBase;
  
  
cout << "What is the Base? ";
cin >> triBase;
cout << "What is the Height? ";
cin >> triHeight;
 
ob.setBase(triBase);
ob.setHeight(triHeight);
  
cout << "The Triangles data:\n";
cout << "Base is " << ob.getBase() << endl;
cout << "Height is " << ob.getHeight() << endl;
cout << "Area is " << ob.getArea() << endl;
  
  return 0;
}