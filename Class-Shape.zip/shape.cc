//Shape class implementation	   
//Shape.cc

//#define Pi 3.1416


Shape::Shape()
{
center_x = 0;
center_y = 0;
radius = 5.0;
}


Shape::Shape(double x, double y, double r)
{
center_x = x;
center_y = y;
radius = r;
}

void Shape::setCenter(double dx, double dy)
{
center_x = dx;
center_y = dy;
}


double Shape::getRadius() const
{
return radius;
}

// abstract draw method
void Shape::draw()
{
}