//main.ccpp
#include<iostream>

#include "shape.h"
#include "shape.cc"

using namespace std;

int main()
{

Shape s1;
s1.setCenter(4.0,3.0);

cout << "Radius: " << s1.getRadius() <<"\n";

return 0;

}  
  
  