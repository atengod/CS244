//Shape class declaration
//shape.h 

#ifndef SHAPES_H
#define SHAPES_H

#include <iostream> 
#include <string>

#define NDEBUG 

//#include <cassert>

using namespace std;

class Shape
{
private:
 // string name;
  double center_x;
	double center_y;
	double radius;

public:
  Shape();
  Shape(double x, double y, double r);
  
 // string getName() const;
  double getRadius() const; 
 
  virtual void draw();
  
  void display() const;
  void setCenter(double, double); 
 // void setName(string);
};


#endif
