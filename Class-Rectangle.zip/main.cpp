//main.ccpp
//#include<iostream>
//#include "rectangle.h"

#include "rectangle.cc"

//using namespace std;

int main() 
{
  Rectangle box;
  double rectWidth;
  double rectLength;
  
  
  cout << "What is the Width? ";
  cin >> rectWidth;
  cout << "What is the Length? ";
  cin >> rectLength;
 
  
  
  box.setWidth(rectWidth);
  box.setLength(rectLength);
  
  cout << "Here is the rectangles data:\n";
  cout << "Width: " << box.getWidth() << endl;
  cout << "Length: " << box.getLength() << endl;
  cout << "Area: " << box.getArea() << endl;
  
  return 0;
}