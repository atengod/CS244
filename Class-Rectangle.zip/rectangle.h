#ifndef RECTANGLE_H
#define RECTANGLE_H

#include <iostream> 
#include <string>

#define NDEBUG 

using namespace std;

class Rectangle

{

private:
 double length;
 double width;
 
public:
Rectangle();
double getLength() const;
double getWidth() const;
void setWidth(double);
void setLength(double);
double getArea() const;

};

#endif