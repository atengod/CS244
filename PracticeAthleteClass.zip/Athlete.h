#ifndef ATHLETE
#define ATHLETE

#include<iostream>

#define NDEBUG

#include <cassert>


using namespace std;

class Athlete
{
  private:

    string name;
    string sport;
    string team;
    double weight;
    double salary;

  public:
    Athlete();
    Athlete(string name, string sport,string team, double weight, double salary);

 // getters
    string getName();
    string getSport();
    string getTeam();
    double getWeight();
    double getSalary();

 // setters
    void setName(string name);
    void setSport(string sport);
    void setTeam(string team);
    void setWeight(double weight);
    void setSalary(double salary);

};

#endif