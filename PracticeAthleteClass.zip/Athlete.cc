
Athlete::Athlete()
{
    name = "";
    sport = "";
    team = "";
    weight = 0.0;
    salary = 0.0;
}

Athlete::Athlete(string newName, string newSport, string newTeam, double newWeight, double newSalary)
{
    name = newName;
    sport = newSport;
    team = newTeam;
    weight = newWeight;
    salary = newSalary;
}

// getters

string Athlete::getName()
{
    return name;
}


string Athlete::getSport()
{
    return sport;
}


string Athlete::getTeam()
{
    return team;
}


double Athlete::getWeight()
{
    return weight;
}


double Athlete::getSalary()
{
    return salary;
}



// setters


void Athlete::setName(string newName)
{
    name = newName;
}


void Athlete::setSport(string newSport)
{
    sport = newSport;
}


void Athlete::setTeam(string newTeam)
{
    team = newTeam;
}


void Athlete::setWeight(double newWeight)
{
    weight = newWeight;
}


void Athlete::setSalary(double newSalary)
{
    salary = newSalary;
}