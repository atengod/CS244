//main.ccpp
#include<iostream>
#include "Athlete.h"
#include "Athlete.cc"
using namespace std;


int main()

{

    Athlete ob("Pance Shay" , "Soccer" , "USA" , 68.5 , 1000000);

   

    cout<<"Name : "<<ob.getName()<<endl;

    cout<<"Sport : "<<ob.getSport()<<endl;

    cout<<"Team : "<<ob.getTeam()<<endl;

    cout<<"Weight : "<<ob.getWeight()<<endl;

    cout<<"Salary : $"<<ob.getSalary();

   

    return 0;

}