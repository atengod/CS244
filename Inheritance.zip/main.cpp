//main.ccpp
#include<iostream>

using namespace std;


#include "circle.cc"
#include "rectangle.cc"
#include "triangle.cc"



int main()
{
  
//float a[6] = {circle, rectangle, triangle, oval, square, cone}; 
//int maxIndex=0;   //for max value index
//int maxVal = a[0];   //max value of array
//for(int i=0; i<6; i++)
//{
//if(a[i] > maxVal)   
//{
//     maxIndex = i;   //store index to maxIndex
//       maxVal = a[i];   //maxVal is updated
//     }
//   }
  
  
  
Shape s2;
s2.setCenter(4.0,3.0);

cout << s2.getRadius() <<"\n" << endl;




  
  
Circle c1(4.0,6.0,2.0);
Circle c2;
c2.setCenter(4.0,3.0);

cout << "Circle 2's info is:" << "\n";
cout << c2.getArea() << "\n";
cout << c2.getRadius() <<"\n";
cout << c2.getDiameter() << "\n";
cout << c2.getCircum() << "\n" << endl;

cout << "Circle 1's info is:" << "\n";
cout << c1.getArea() << "\n";
cout << c1.getRadius() << "\n";
cout << c1.getDiameter() << "\n";
cout << c1.getCircum() << endl << endl;



  
  
  
Rectangle box;
double rectWidth;
double rectLength;
  
cout << "What is the Width? ";
cin >> rectWidth;
cout << "What is the Length? ";
cin >> rectLength;
 
box.setWidth(rectWidth);
box.setLength(rectLength);
  
cout << "Here is the rectangles data:\n";
cout << "Width: " << box.getWidth() << endl;
cout << "Length: " << box.getLength() << endl;
cout << "Area: " << box.getArea() << endl << endl;
  






Triangle ob;
double triHeight;
double triBase;
  
cout << "What is the Base? ";
cin >> triBase;
cout << "What is the Height? ";
cin >> triHeight;
 
ob.setBase(triBase);
ob.setHeight(triHeight);
  
cout << "The Triangles data:\n";
cout << "Base is " << ob.getBase() << endl;
cout << "Height is " << ob.getHeight() << endl;
cout << "Area is " << ob.getArea() << endl;
  
return 0;

}
  