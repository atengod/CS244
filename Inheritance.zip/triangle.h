//Triangle class declaration
//Triangle.h


class Triangle : public Shape
{
private:
  double base;
  double height;

public:
  Triangle();  //Constructor
  
  //getters
  
  double getHeight() const; 
  double getBase() const;
  double getArea() const;
  
  //setters
  
  void setBase(double);
  void setHeight(double);
};