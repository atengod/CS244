#include "shape.cc"

class Circle : public Shape   
{
  protected:
    double radius;
    double center_x;
	  double center_y;
			 
  public:
    Circle(); 
    Circle(double x, double y, double r);
   
    double getDiameter() const;
    double getCircum() const;
    double getRadius() const;   //Constructor
  	double getArea() const;
  	
  	void setCenter(double, double); 

  
};			