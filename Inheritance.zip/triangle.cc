//triangle class implementation	   
//triangle.cc

#include "triangle.h"

#define hf 0.5

Triangle::Triangle()
{
base = 0.0;
height = 0.0;
}


//getters 


double Triangle::getHeight() const
{
return height;
}


double Triangle::getBase() const
{
return base;
}


double Triangle::getArea() const
{
return hf * base * height;
}

//setters


void Triangle::setHeight(double h) 
{
height = h;
}


void Triangle::setBase(double b)
{
base = b;
}
