//#include "shape.cc"

class Rectangle : public Shape

{

private:
 double length;
 double width;
 
public:
Rectangle();
double getLength() const;
double getWidth() const;
void setWidth(double);
void setLength(double);
double getArea() const;

};
