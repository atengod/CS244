//Shape class implementation	   
//Shape.cc

#include "shape.h"

#define Pi 3.1416





Shape::Shape(double x = 0, double y = 0, double r = 5)
{
center_x = x;
center_y = y;
radius = r;
}

void Shape::setCenter(double dx, double dy)
{
center_x = dx;
center_y = dy;
}


double Shape::getRadius() const
{
return radius;
}

// abstract draw method
void Shape::draw()
{
}