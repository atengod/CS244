//Circle class declaration
//Circle.h
class Circle
{
  private:
    double radius;
    double center_x;
	  double center_y;
			 
  public:
    Circle(); 
    Circle(double x, double y, double r);
    double getDiameter() const;
    double getCircum() const;
    double getRadius() const;   //Constructor
  	double getArea() const;
  	void setCenter(double, double); 
};			