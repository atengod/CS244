//Circle class implementation	   
//Circle.cc
#define Pi 3.1416
Circle::Circle()
{
center_x = 0;
center_y = 0;
radius = 5.0;
}

Circle::Circle(double x, double y, double r)
{
center_x = x;
center_y = y;
radius = r;
}

void Circle::setCenter(double dx, double dy)
{
center_x = dx;
center_y = dy;
}


double Circle::getCircum() const
{
   return Pi * getDiameter();
}


double Circle::getDiameter() const
{
   return (2 * radius); 
}


double Circle::getArea() const
{
    return Pi * radius * radius;
}


double Circle::getRadius() const
{
    return radius;
}



