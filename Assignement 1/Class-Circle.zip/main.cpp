//main.ccpp
#include<iostream>
#include "circle.h"
#include "circle.cc"
using namespace std;

int main()
{
Circle c1(4.0,6.0,2.0);
Circle c2;
c2.setCenter(4.0,3.0);

cout << c2.getArea() << "\n";
cout << c2.getRadius() <<"\n";
cout << c2.getDiameter() << "\n";
cout << c2.getCircum() << "\n" << endl;

cout << c1.getArea() << "\n";
cout << c1.getRadius() << "\n";
cout << c1.getDiameter() << "\n";
cout << c1.getCircum() << "\n";


return 0;
}  
  
  